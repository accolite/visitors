import { Component, OnInit } from '@angular/core';

@Component( {
  selector: 'app-navigation',
  templateUrl: './vertical-navbar.component.html',
  styleUrls: [ './vertical-navbar.component.css' ]
} )
export class NavigationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
