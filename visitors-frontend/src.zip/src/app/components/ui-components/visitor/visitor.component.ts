import { Component, OnInit } from '@angular/core';

@Component( {
  selector: 'app-visitor',
  templateUrl: './visitor.component.html',
  styleUrls: [ './visitor.component.css' ]
} )
export class VisitorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
