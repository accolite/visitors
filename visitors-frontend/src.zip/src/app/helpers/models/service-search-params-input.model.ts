/**
 *  @author M.Shashikant(shashikant.mittapelli@accoliteindia.com)
 *  Helper For Http params to be used by lower level components
 */

export class ServiceSearchParamsInputModel {
  size: number = 10;
  [ props: string ]: any;
}