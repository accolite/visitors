// Add Accolite related static data 

export const accoliteLocation = [ 'Bangalore', 'Hyderabad', 'Delhi' ];